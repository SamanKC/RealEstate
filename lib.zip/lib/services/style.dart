import 'package:flutter/material.dart';

const white = Colors.white;
const black = Colors.black;
const indigo = Colors.indigoAccent;
const grey = Colors.grey;